
#include "mastergoal.h"

#include <gtk/gtk.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

EstadoJuego estado_actual = comenzando;

int pases_restantes = 4;
bool movimiento_realizado = false;
bool seleccion_jugador = false;


void imprimir_en_consola(const char *mensaje) {
    if (consola_textview) {
        GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(consola_textview));
        GtkTextIter end;
        gtk_text_buffer_get_end_iter(buffer, &end);
        gtk_text_buffer_insert(buffer, &end, mensaje, -1);
        gtk_text_buffer_insert(buffer, &end, "\n", -1);
    }
}

void guardar_estadisticas(GList *estadisticas, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Error al guardar estadísticas");
        return;
    }

    for (GList *node = estadisticas; node; node = node->next) {
        EstadisticaJugador *jugador = (EstadisticaJugador *)node->data;
        fprintf(file, "%s %d %d %d\n", jugador->nombre, jugador->partidas_jugadas,
                jugador->partidas_ganadas, jugador->partidas_perdidas);
    }
    fclose(file);
}

void actualizar_estadisticas(GList **estadisticas, const char *nombre, int ganado) {
    GList *node = *estadisticas;
    while (node) {
        EstadisticaJugador *jugador = (EstadisticaJugador *)node->data;
        if (strcmp(jugador->nombre, nombre) == 0) {
            jugador->partidas_jugadas++;
            if (ganado)
                jugador->partidas_ganadas++;
            else
                jugador->partidas_perdidas++;
            return;
        }
        node = node->next;
    }


    EstadisticaJugador nuevo = {0};
    strncpy(nuevo.nombre, nombre, sizeof(nuevo.nombre) - 1);
    nuevo.partidas_jugadas = 1;
    if (ganado)
        nuevo.partidas_ganadas = 1;
    else
        nuevo.partidas_perdidas = 1;
    *estadisticas = g_list_append(*estadisticas, g_memdup2(&nuevo, sizeof(EstadisticaJugador)));
}

int ordenar_estadisticas(const void *a, const void *b) {
    const EstadisticaJugador *jugador_a = a;
    const EstadisticaJugador *jugador_b = b;

    return jugador_b->partidas_ganadas - jugador_a->partidas_ganadas; // Ordenar
}

void mostrar_ganador(const char *ganador) {
    GtkWidget *dialog = gtk_message_dialog_new(
        NULL,
        GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "%s GANA!", ganador
    );
    gtk_window_set_title(GTK_WINDOW(dialog), "Resultado:");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

void mostrar_empate() {
    GtkWidget *dialog = gtk_message_dialog_new(
        NULL,
        GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Opa empate."
    );
    gtk_window_set_title(GTK_WINDOW(dialog), "Resultado:");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

void inicializar_tablero(Tablero *tablero) {
    // Inicializar el tablero vacío
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            tablero->celdas[i][j].tipo = VACIO;
            tablero->celdas[i][j].adyacente_rojo = 0;
            tablero->celdas[i][j].adyacente_blanco = 0;
            tablero->celdas[i][j].es_area = false;
            tablero->celdas[i][j].es_area_chica = false;
            tablero->celdas[i][j].es_especial = false;
        }
    }
    int arco_inicio = (columnas - 5) / 2;
    for (int j = arco_inicio; j < arco_inicio + 5; j++) {
        tablero->celdas[0][j].tipo = arco;
        tablero->celdas[filas - 1][j].tipo = arco;
    }
    int especiales[][2] = {
        {0, 0}, {0, 10}, {12, 0}, {12, 10},
        {0, 3}, {0, 4}, {0, 5}, {0, 6}, {0, 7},
        {12, 3}, {12, 4}, {12, 5}, {12, 6}, {12, 7}
    };
    for (int i = 0; i < sizeof(especiales) / sizeof(especiales[0]); i++) {
        int x = especiales[i][0];
        int y = especiales[i][1];
        tablero->celdas[x][y].es_especial = true;
    }
    tablero->balon.x = 6;
    tablero->balon.y = 5;
    tablero->celdas[6][5].tipo = BALON;

    tablero->equipo_rojo[0] = (Jugador){2, 5, 0, arquero_rojo};
    tablero->equipo_rojo[1] = (Jugador){3, 3, 1, jugador_rojo};
    tablero->equipo_rojo[2] = (Jugador){3, 7, 2, jugador_rojo};
    tablero->equipo_rojo[3] = (Jugador){5, 2, 3, jugador_rojo};
    tablero->equipo_rojo[4] = (Jugador){5, 8, 4, jugador_rojo};

    tablero->equipo_blanco[0] = (Jugador){10, 5, 0, arquero_blanco};
    tablero->equipo_blanco[1] = (Jugador){9, 3, 1, jugador_blanco};
    tablero->equipo_blanco[2] = (Jugador){9, 7, 2, jugador_blanco};
    tablero->equipo_blanco[3] = (Jugador){7, 2, 3, jugador_blanco};
    tablero->equipo_blanco[4] = (Jugador){7, 8, 4, jugador_blanco};
//Colocar jugadores
    for (int i = 0; i < 5; i++) {
        tablero->celdas[tablero->equipo_rojo[i].x][tablero->equipo_rojo[i].y].tipo = tablero->equipo_rojo[i].tipo;
        tablero->celdas[tablero->equipo_blanco[i].x][tablero->equipo_blanco[i].y].tipo = tablero->equipo_blanco[i].tipo;
    }

    if (color_jugador_inicial != sin_color) {
        turno.jugador_actual = (color_jugador_inicial == rojo) ? 1 : 2;
    } else if (color_random) {
        turno.jugador_actual = (rand() % 2) + 1;
    } else {
        turno.jugador_actual = (color_jugador1 == rojo) ? 1 : 2;
    }

    estado_actual = En_Juego;

    char mensaje[100];
    snprintf(mensaje, sizeof(mensaje), "Inicia el juego: %s (%s)",
             turno.jugador_actual == 1 ? nombre_jugador1 : nombre_jugador2,
             turno.jugador_actual == 1 ? "rojo" : "blanco");
    imprimir_en_consola(mensaje);
}

void cargar_tablero_desde_glade(Juego *juego, GtkBuilder *builder) {
    juego->grid = GTK_WIDGET(gtk_builder_get_object(builder, "tablero_grid"));

    int arco_inicio = (columnas - 5) / 2;
    gtk_grid_set_row_spacing(GTK_GRID(juego->grid), 0);
    gtk_grid_set_column_spacing(GTK_GRID(juego->grid), 0);

    // Fila arriba del arco
    for (int j = 0; j < 5; j++) {
        juego->buttons[0][arco_inicio + j] = gtk_button_new_with_label(" ");
        gtk_widget_set_size_request(GTK_WIDGET(juego->buttons[0][arco_inicio + j]), 37, 37);
        gtk_widget_set_hexpand(GTK_WIDGET(juego->buttons[0][arco_inicio + j]), FALSE);
        gtk_widget_set_vexpand(GTK_WIDGET(juego->buttons[0][arco_inicio + j]), FALSE);
        gtk_button_set_relief(GTK_BUTTON(juego->buttons[0][arco_inicio + j]), GTK_RELIEF_NONE);
        gtk_grid_attach(GTK_GRID(juego->grid), juego->buttons[0][arco_inicio + j], arco_inicio + j, 0, 1, 1);
        int *pos = malloc(2 * sizeof(int));
        pos[0] = 0;
        pos[1] = arco_inicio + j;
        g_object_set_data(G_OBJECT(juego->buttons[0][arco_inicio + j]), "pos", pos);
        g_signal_connect(juego->buttons[0][arco_inicio + j], "clicked", G_CALLBACK(on_casilla_clicked), juego);
    }
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            juego->buttons[i + 1][j] = gtk_button_new_with_label(" ");
            gtk_widget_set_size_request(GTK_WIDGET(juego->buttons[i + 1][j]), 37, 37);
            gtk_widget_set_hexpand(GTK_WIDGET(juego->buttons[i + 1][j]), FALSE);
            gtk_widget_set_vexpand(GTK_WIDGET(juego->buttons[i + 1][j]), FALSE);
            gtk_button_set_relief(GTK_BUTTON(juego->buttons[i + 1][j]), GTK_RELIEF_NONE);
            gtk_grid_attach(GTK_GRID(juego->grid), juego->buttons[i + 1][j], j, i + 1, 1, 1);
            int *pos = malloc(2 * sizeof(int));
            pos[0] = i;
            pos[1] = j;
            g_object_set_data(G_OBJECT(juego->buttons[i + 1][j]), "pos", pos);
            g_signal_connect(juego->buttons[i + 1][j], "clicked", G_CALLBACK(on_casilla_clicked), juego);
        }
    }

    // Fila abajo del arco
    for (int j = 0; j < 5; j++) {
        juego->buttons[filas + 1][arco_inicio + j] = gtk_button_new_with_label(" ");
        gtk_widget_set_size_request(GTK_WIDGET(juego->buttons[filas + 1][arco_inicio + j]), 37, 37);
        gtk_widget_set_hexpand(GTK_WIDGET(juego->buttons[filas + 1][arco_inicio + j]), FALSE);
        gtk_widget_set_vexpand(GTK_WIDGET(juego->buttons[filas + 1][arco_inicio + j]), FALSE);
        gtk_button_set_relief(GTK_BUTTON(juego->buttons[filas + 1][arco_inicio + j]), GTK_RELIEF_NONE);
        gtk_grid_attach(GTK_GRID(juego->grid), juego->buttons[filas + 1][arco_inicio + j], arco_inicio + j, filas + 1, 1, 1);
        int *pos = malloc(2 * sizeof(int));
        pos[0] = filas + 1;
        pos[1] = arco_inicio + j;
        g_object_set_data(G_OBJECT(juego->buttons[filas + 1][arco_inicio + j]), "pos", pos);
        g_signal_connect(juego->buttons[filas + 1][arco_inicio + j], "clicked", G_CALLBACK(on_casilla_clicked), juego);
    }

    actualizar_tablero_grafico(juego);
    gtk_widget_show_all(GTK_WIDGET(juego->grid));
}

void actualizar_tablero_grafico(Juego *juego) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            char contenido = juego->tablero->celdas[i][j].tipo;
            const char *texto;

            switch (contenido) {
                case VACIO:
                    texto = " ";
                    break;
                case BALON:
                    texto = "⚽";
                    break;
                case jugador_rojo:
                    texto = "🔴";
                    break;
                case jugador_blanco:
                    texto = "⚪";
                    break;
                case arquero_rojo:
                    texto = "🟥";
                    break;
                case arquero_blanco:
                    texto = "⬜";
                    break;
                case arco:
                    texto = " ";
                    break;
                default:
                    texto = " ";
            }

            gtk_button_set_label(GTK_BUTTON(juego->buttons[i + 1][j]), texto);
        }
    }
}

void actualizar_marcador(int goles_rojo, int goles_blanco) {
    char marcador[50];
    snprintf(marcador, sizeof(marcador), "Rojo %d   -   Blanco %d", goles_rojo, goles_blanco);
    gtk_label_set_text(GTK_LABEL(marcador_label), marcador);
}

// Función para verificar si una casilla está dentro del área grande del portero
bool area_grande_arquero(int x, int y, char tipo_portero) {
    // Área grande para el portero rojo (parte superior del tablero)
    if (tipo_portero == arquero_rojo && x >= 0 && x <= 3 && y >= 2 && y <= 8) {
        return true;
    }

    // Área grande para el portero blanco (parte inferior del tablero)
    if (tipo_portero == arquero_blanco && x >= 9 && x <= 12 && y >= 2 && y <= 8) {
        return true;
    }

    return false;
}

bool balon_solo(Tablero *tablero) {
    int x = tablero->balon.x;
    int y = tablero->balon.y;

    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue;
            int nx = x + i;
            int ny = y + j;

            if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
                char contenido = tablero->celdas[nx][ny].tipo;
                if (contenido == jugador_rojo || contenido == jugador_blanco ||
                    contenido == arquero_rojo || contenido == arquero_blanco) {
                    return false;  // Hay un jugador adyacente
                }
            }
        }
    }

    return true;  // El balón está aislado
}

bool es_gol(Tablero *tablero, int x, int y, int equipo) {
    int arco_inicio = (columnas - 5) / 2;  // Mismo cálculo que en cargar_tablero_desde_glade
    int arco_fin = arco_inicio + 4;

    // Verificar si el balón entra en el arco del equipo contrario
    if (equipo == 1 && x == 0 && y >= arco_inicio && y <= arco_fin) {
        return true; // Gol del equipo rojo
    } else if (equipo == 2 && x == filas + 1 && y >= arco_inicio && y <= arco_fin) {
        return true; // Gol del equipo blanco
    }

    return false;
}


void verificar_condiciones_finalizacion(Juego *juego) {
    //Tablero *tablero = juego->tablero;
    static int total_jugadas = 10; // Máximo número de jugadas permitidas

    // Verificar si se han agotado las jugadas
    total_jugadas--;
    if (total_jugadas <= 0) {
        imprimir_en_consola("Se acabaron las jugadas posibles");
        finalizar_partido(juego, juego->goles_rojo, juego->goles_blanco, total_jugadas);
        return;
    }
}
// Función para mover un jugador a una nueva posición
void mover_jugador(Juego *juego, Jugador *jugador, int nueva_x, int nueva_y) {
    if (turno.movimiento_realizado) {
        imprimir_en_consola("Ya se ha movido un jugador en este turno.");
        return;
    }

    Tablero *tablero = juego->tablero;

    // Verificar si el jugador pertenece al equipo en turno
    if ((jugador->tipo == jugador_rojo || jugador->tipo == arquero_rojo) && turno.jugador_actual != 1) {
        imprimir_en_consola("Turno de los Blancos.");
        return;
    } else if ((jugador->tipo == jugador_blanco || jugador->tipo == arquero_blanco) && turno.jugador_actual != 2) {
        imprimir_en_consola("Turnos de los Rojos.");
        return;
    }

    // Verificar que la nueva posición esté dentro del rango permitido
    int dx = abs(jugador->x - nueva_x);
    int dy = abs(jugador->y - nueva_y);

    if (dx > 2 || dy > 2 || (dx > 0 && dy > 0 && dx != dy)) {
        imprimir_en_consola("Movimiento inválido: Los jugadores solo pueden avanzar hasta 2.");
        return;
    }

    // Verificar que la nueva casilla esté vacía
    if (tablero->celdas[nueva_x][nueva_y].tipo != VACIO) {
        imprimir_en_consola("La casilla está ocupada.");
        return;
    }

    // Actualizar la posición del jugador
    tablero->celdas[jugador->x][jugador->y].tipo = VACIO;
    jugador->x = nueva_x;
    jugador->y = nueva_y;
    tablero->celdas[nueva_x][nueva_y].tipo = jugador->tipo;

    // Actualizar el tablero gráfico
    actualizar_tablero_grafico(juego);

    // Marcar que el jugador se movió en este turno
    turno.movimiento_realizado = true;

    // Verificar si el jugador quedó adyacente al balón
    bool jugador_adyacente_al_balon = false;
    int bx = juego->tablero->balon.x;
    int by = juego->tablero->balon.y;

    for (int i = -1; i <= 1 && !jugador_adyacente_al_balon; i++) {
        for (int j = -1; j <= 1 && !jugador_adyacente_al_balon; j++) {
            if (i == 0 && j == 0) continue;
            int nx = jugador->x + i;
            int ny = jugador->y + j;
            if (nx == bx && ny == by) {
                jugador_adyacente_al_balon = true;
            }
        }
    }

    if (jugador_adyacente_al_balon) {
        // El equipo tiene derecho a hacer hasta 4 pases
        turno.pases_restantes = 4;
        imprimir_en_consola("Jugador adyacente al balón, puedes hacer pases");
    } else {
        // Si no está adyacente, se termina el turno
        imprimir_en_consola("Jugador no adyacente al balón. Fin del turno.");
        finalizar_turno(juego); // MODIFICADO: Ahora llamamos a finalizar_turno
    }
}

void mover_balon(Juego *juego, int nueva_x, int nueva_y) {
    Tablero *tablero = juego->tablero;
    int dx = abs(tablero->balon.x - nueva_x);
    int dy = abs(tablero->balon.y - nueva_y);

    // Verificar si se tienen pases restantes
    if (turno.pases_restantes <= 0) {
        imprimir_en_consola("No hay pases disponibles.");
        return;
    }

    // Verificar línea recta o diagonal hasta 4 casillas
    if (!((dx == 0 || dy == 0 || dx == dy) || dx <= 4 || dy <= 4)) {
        imprimir_en_consola("Movimiento inválido: El balón solo puede moverse hasta 4 casillas.");
        return;
    }

    // Verificar posesión del balón
    int posesion = verificar_posesion(tablero);
    if (posesion != turno.jugador_actual) {
        imprimir_en_consola("No tienes posesión del balón.");
        return;
    }

    // Verificar destino
    char destino = tablero->celdas[nueva_x][nueva_y].tipo;
    if (destino != VACIO && destino != arco) {
        imprimir_en_consola("Movimiento inválido.");
        return;
    }

    // Verificar si el movimiento resulta en un gol
    if (es_gol(tablero, nueva_x, nueva_y, turno.jugador_actual)) {
        gestionar_gol(juego, turno.jugador_actual);
        return;
    }

    // Realizar el movimiento del balón
    tablero->celdas[tablero->balon.x][tablero->balon.y].tipo = VACIO;
    tablero->balon.x = nueva_x;
    tablero->balon.y = nueva_y;
    tablero->celdas[nueva_x][nueva_y].tipo = BALON;
    actualizar_tablero_grafico(juego);

    // Decrementar pases restantes
    turno.pases_restantes--;

    char mensaje[100];
    snprintf(mensaje, sizeof(mensaje), "Balón movido a (%d, %d). Pases restantes: %d", nueva_x, nueva_y, turno.pases_restantes);
    imprimir_en_consola(mensaje);

    // Verificar si el balón ha quedado aislado tras este pase
    if (balon_solo(tablero)) {
        // Si el balón queda aislado después del pase, se debe finalizar el turno inmediatamente.
        imprimir_en_consola("El balón está aislado. Fin del turno.");
        finalizar_turno(juego);
        return;
    }

    // Si no está aislado y ya no hay más pases, finalizar el turno de todas formas
    if (turno.pases_restantes == 0) {
        imprimir_en_consola("No hay más pases disponibles. Fin del turno.");
        finalizar_turno(juego);
        return;
    }

    // Si hay más pases y el balón no está aislado, el turno continúa.
    imprimir_en_consola("Aún puedes realizar más pases.");
}

void juegaComp_pregunta(Juego *juego) {
    // Si el modo de juego es J1 vs CPU y es turno del equipo 2 (la CPU)
    if (modo_juego == modoj1vpc && turno.jugador_actual == 2) {
        imprimir_en_consola("Turno de la CPU. La CPU está pensando...");
        moverComp(juego, 2);
    }
    // Si el modo es CPU vs CPU, sin importar quién es el actual, la CPU juega
    else if (modo_juego == modopcpc) {
        imprimir_en_consola("Turno de la CPU. La CPU está pensando...");
        moverComp(juego, turno.jugador_actual);
    }

}

void cambiarTurno(Juego *juego) {
    verificar_condiciones_finalizacion(juego);
    turno.jugador_actual = (turno.jugador_actual == 1) ? 2 : 1;
    turno.pases_restantes = 0; // Al inicio del turno no hay pases asignados
    turno.movimiento_realizado = false;

    char mensaje[100];
    snprintf(mensaje, sizeof(mensaje), "Cambio de turno: Equipo %s.",
             (turno.jugador_actual == 1) ? "Rojo" : "Blanco");
    imprimir_en_consola(mensaje);

    // Llamar a la función que verifica si debe jugar la CPU en este turno
    juegaComp_pregunta(juego);
}

// Maneja las condiciones de finalización del partido
void finalizar_partido(Juego *juego, int goles_rojo, int goles_blanco, int total_jugadas) {
    char mensaje[150];

    // 2. Verificar si algún equipo alcanza 2 goles
    if (goles_rojo >= 2) {
        snprintf(mensaje, sizeof(mensaje), "EL ROJO GANA", goles_rojo);
        imprimir_en_consola(mensaje);
        mostrar_ganador("Equipo Rojo");
        actualizar_estadisticas(&juego->estadisticas, nombre_jugador1, 1); // Ganó el rojo
        actualizar_estadisticas(&juego->estadisticas, nombre_jugador2, 0); // Perdió el blanco
        guardar_estadisticas(juego->estadisticas, "estadisticas.txt");
        gtk_main_quit(); // Finaliza el juego
        return;
    } else if (goles_blanco >= 2) {
        snprintf(mensaje, sizeof(mensaje), "EL BLANCO GANA", goles_blanco);
        imprimir_en_consola(mensaje);
        mostrar_ganador("Equipo Blanco");
        actualizar_estadisticas(&juego->estadisticas, nombre_jugador2, 1); // Ganó el blanco
        actualizar_estadisticas(&juego->estadisticas, nombre_jugador1, 0); // Perdió el rojo
        guardar_estadisticas(juego->estadisticas, "estadisticas.txt");
        gtk_main_quit(); // Finaliza el juego
        return;
    }

    // 3. Verificar si se agotaron las jugadas
    if (total_jugadas <= 0) {
        snprintf(mensaje, sizeof(mensaje), "El partido finaliza en empate: Rojo %d - Blanco %d.",
                 goles_rojo, goles_blanco);
        imprimir_en_consola(mensaje);
        mostrar_empate();

        // Guardar estadísticas
        guardar_estadisticas(juego->estadisticas, "estadisticas.txt");

        gtk_main_quit(); // Finaliza el juego
        return;
    }
}

void gestionar_gol(Juego *juego, int equipo) {
    if (equipo == 1) {
        juego->goles_rojo++;
        imprimir_en_consola("¡Gol de los rojos!");
    } else if (equipo == 2) {
        juego->goles_blanco++;
        imprimir_en_consola("¡Gol de los blancos!");
    }

    actualizar_marcador(juego->goles_rojo, juego->goles_blanco);


    // Verificar si el equipo ha ganado
    if (juego->goles_rojo == 2 || juego->goles_blanco == 2) {
        char ganador[50];
        if (juego->goles_rojo == 2) {
            snprintf(ganador, sizeof(ganador), "Equipo Rojo");
            actualizar_estadisticas(&juego->estadisticas, nombre_jugador1, 1); // Ganó el rojo
            actualizar_estadisticas(&juego->estadisticas, nombre_jugador2, 0); // Perdió el blanco
        } else {
            snprintf(ganador, sizeof(ganador), "Equipo Blanco");
            actualizar_estadisticas(&juego->estadisticas, nombre_jugador2, 1); // Ganó el blanco
            actualizar_estadisticas(&juego->estadisticas, nombre_jugador1, 0); // Perdió el rojo
        }

        // Mostrar diálogo de ganador
        mostrar_ganador(ganador);

        // Guardar estadísticas
        guardar_estadisticas(juego->estadisticas, "estadisticas.txt");

        gtk_main_quit(); // Finaliza el juego
        return;
    }

    // Verificar si se han agotado las jugadas
    if (juego->goles_rojo + juego->goles_blanco >= 4) { // Ejemplo de condición de jugadas
        char mensaje[150];
        snprintf(mensaje, sizeof(mensaje), "El partido finaliza en empate: Rojo %d - Blanco %d.",
                 juego->goles_rojo, juego->goles_blanco);
        imprimir_en_consola(mensaje);
        mostrar_empate();

        // Guardar estadísticas
        guardar_estadisticas(juego->estadisticas, "estadisticas.txt");

        gtk_main_quit(); // Finaliza el juego
        return;
    }

    // Reiniciar posiciones iniciales para continuar el partido
    reiniciar_posiciones_iniciales(juego);

    // Asignar el turno al equipo contrario
    turno.jugador_actual = (equipo == 1) ? 2 : 1;
    char mensaje_turno[100];
    snprintf(mensaje_turno, sizeof(mensaje_turno), "Turno del equipo %s.", (turno.jugador_actual == 1) ? "Rojo" : "Blanco");
    imprimir_en_consola(mensaje_turno);
}

// Función para reiniciar el tablero a las posiciones iniciales
void reiniciar_posiciones_iniciales(Juego *juego) {

    // Llamar a la función inicializar_tablero para reiniciar el tablero
    inicializar_tablero(juego->tablero);

    g_print("Tablero reiniciado a las posiciones iniciales.\n");
}

// Función para cerrar la aplicación
void salir_app(GtkButton *button, gpointer user_data) {
    gtk_main_quit();
}

// Función para verificar si una casilla es especial en relación al portero
bool es_casilla_especial_portero(int x, int y, Tablero *tablero, char tipo_portero) {
    // Determinar la posición del portero correspondiente
    Jugador *equipo = (tipo_portero == arquero_rojo) ? tablero->equipo_rojo : tablero->equipo_blanco;

    for (int i = 0; i < 5; i++) {
        if (equipo[i].tipo == tipo_portero) {
            // Verificar si la casilla está a la izquierda o derecha del portero
            if ((equipo[i].x == x && equipo[i].y == y - 1) ||
                (equipo[i].x == x && equipo[i].y == y + 1)) {
                return true;
            }
        }
    }
    return false;
}

// Función para verificar si un movimiento del balón es válido
bool es_movimiento_valido_balon(Tablero *tablero, int origen_x, int origen_y, int destino_x, int destino_y, int equipo) {
    int dx = abs(origen_x - destino_x);
    int dy = abs(origen_y - destino_y);

    // Verificar que la distancia no exceda el rango permitido y que sea línea recta
    if (!(dx == 0 || dy == 0 || dx == dy) || dx > 4 || dy > 4) {
        imprimir_en_consola("El pase no cumple con las reglas de movimiento.");
        return false;
    }

    // Verificar que el destino está vacío o es un arco
    char contenido_destino = tablero->celdas[destino_x][destino_y].tipo;
    if (contenido_destino != VACIO && contenido_destino != arco) {
        imprimir_en_consola("El destino no está vacío ni es un arco.");
        return false;
    }

    // Verificar posesión del balón
    int posesion = verificar_posesion(tablero);
    if (posesion != equipo) {
        imprimir_en_consola("No tienes posesión del balón.");
        return false;
    }

    // Verificar que el movimiento no viola las reglas del portero
    if (area_grande_arquero(destino_x, destino_y, (equipo == 1) ? arquero_rojo : arquero_blanco)) {
        imprimir_en_consola("Movimiento inválido: No puedes mover el balón dentro del área del portero.");
        return false;
    }

    // Prohibir mover el balón a las esquinas propias
    if ((equipo == 1 && (destino_x == 12 && (destino_y == 0 || destino_y == 10))) ||
        (equipo == 2 && (destino_x == 0 && (destino_y == 0 || destino_y == 10)))) {
        imprimir_en_consola("Movimiento inválido: No puedes mover el balón a las esquinas propias.");
        return false;
    }

    return true;
}

int verificar_posesion(Tablero *tablero) {
    int x = tablero->balon.x;
    int y = tablero->balon.y;

    int jugadores_equipo1 = 0, jugadores_equipo2 = 0;

    // Contar jugadores adyacentes excluyendo casillas especiales como los brazos del portero
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue; // No incluir la posición del balón
            int nx = x + i;
            int ny = y + j;

            if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
                char contenido = tablero->celdas[nx][ny].tipo;

                if (es_casilla_especial_portero(nx, ny, tablero, arquero_rojo) ||
                    es_casilla_especial_portero(nx, ny, tablero, arquero_blanco)) {
                    continue; // No incluir casillas de los brazos del portero
                }

                if (contenido == jugador_rojo) jugadores_equipo1++;
                if (contenido == jugador_blanco) jugadores_equipo2++;
            }
        }
    }

    // Determinar posesión
    if (jugadores_equipo1 > jugadores_equipo2) return 1; // Equipo rojo
    if (jugadores_equipo2 > jugadores_equipo1) return 2; // Equipo blanco

    return 0; // Casillas neutras
}

void finalizar_turno(Juego *juego) {
    Tablero *tablero = juego->tablero;
    // Verificar si el balón está aislado (sin jugadores adyacentes)
    if (balon_solo(tablero)) {
        imprimir_en_consola("Turno finalizado con el balón en posición neutra.");
    } else {
        imprimir_en_consola("Fin del turno. El balón no quedó en posición neutra, pero no hay más acciones.");
    }

    cambiarTurno(juego);
}

bool posicion_adyacente(Tablero* tablero, int x, int y) {
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue;
            int nx = x + i;
            int ny = y + j;
            if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
                char contenido = tablero->celdas[nx][ny].tipo;
                if (contenido == jugador_rojo || contenido == jugador_blanco || contenido == arquero_rojo || contenido == arquero_blanco) {
                    return false; // Hay un jugador adyacente
                }
            }
        }
    }
    return true; // No hay jugadores adyacentes
}


void on_casilla_clicked(GtkButton *button, gpointer user_data) {
    Juego *juego = (Juego *)user_data;

    if (modo_juego == modoj1vpc && turno.jugador_actual == 2) {
        imprimir_en_consola("Es el turno de la CPU. No puedes realizar acciones ahora.");
        return;
    }

    int *pos = (int *)g_object_get_data(G_OBJECT(button), "pos");
    int x = pos[0];
    int y = pos[1];

    if (!seleccion_jugador) {
        char contenido = juego->tablero->celdas[x][y].tipo;
        if ((contenido == jugador_rojo && turno.jugador_actual == 1) || (contenido == jugador_blanco && turno.jugador_actual == 2) ||
            (contenido == arquero_rojo && turno.jugador_actual == 1) || (contenido == arquero_blanco && turno.jugador_actual == 2)) {

            Jugador *equipo = (turno.jugador_actual == 1) ? juego->tablero->equipo_rojo : juego->tablero->equipo_blanco;
            for (int i = 0; i < 5; i++) {
                if (equipo[i].x == x && equipo[i].y == y) {
                    juego->jugador_seleccionado = &equipo[i];
                    seleccion_jugador = true;
                    char mensaje[50];
                    snprintf(mensaje, sizeof(mensaje), "Jugador seleccionado en (%d, %d)", x, y);
                    imprimir_en_consola(mensaje);
                    return;
                }
            }
        } else if (contenido == BALON) {
            juego->jugador_seleccionado = NULL;
            seleccion_jugador = true;
            imprimir_en_consola("Balón seleccionado, elige destino para el pase.");
        } else {
            imprimir_en_consola("Selecciona un jugador de tu equipo o el balón.");
        }
    } else {
        // Mover jugador o balón
        if (juego->jugador_seleccionado != NULL) {
            mover_jugador(juego, juego->jugador_seleccionado, x, y);
        } else {
            // Si se seleccionó el balón (para un pase)
            mover_balon(juego, x, y);
        }
        seleccion_jugador = false;
    }
}

bool es_posicion_correcta_balon(Tablero *tablero) {
    int x = tablero->balon.x;
    int y = tablero->balon.y;

    for (int dx = -1; dx <= 1; dx++) {
        for (int dy = -1; dy <= 1; dy++) {
            if (dx == 0 && dy == 0) continue;
            int nx = x + dx;
            int ny = y + dy;

            if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
                char contenido = tablero->celdas[nx][ny].tipo;
                if (contenido == jugador_rojo || contenido == jugador_blanco ||
                    contenido == arquero_rojo || contenido == arquero_blanco) {
                    return true; // Hay jugadores cerca
                }
            }
        }
    }
    return false; // El balón está solo
}

int evaluar_posicion(Tablero *tablero, int x, int y, int equipo) {
    int puntaje = 0;

    // Aumentar el puntaje si el balón está cerca del arco contrario
    if (equipo == 1 && x >= 9 && x <= 12) {
        puntaje += 10;  // Área cercana al arco blanco
    } else if (equipo == 2 && x >= 0 && x <= 3) {
        puntaje += 10;  // Área cercana al arco rojo
    }

    // Penalizar posiciones con jugadores adversarios cerca
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            int nx = x + i;
            int ny = y + j;

            if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
                char contenido = tablero->celdas[nx][ny].tipo;
                if ((equipo == 1 && (contenido == jugador_blanco || contenido == arquero_blanco)) ||
                    (equipo == 2 && (contenido == jugador_rojo || contenido == arquero_rojo))) {
                    puntaje -= 5;  // Penalizar jugadores adversarios cerca
                }
            }
        }
    }

    return puntaje;
}

void jugar_computadora(Juego *juego, int equipo) {
    Tablero *tablero = juego->tablero;
    int mejor_puntaje = -1000;
    int mejor_x = -1, mejor_y = -1;

    // Explorar movimientos posibles para el balón
    for (int dx = -4; dx <= 4; dx++) {
        for (int dy = -4; dy <= 4; dy++) {
            int nueva_x = tablero->balon.x + dx;
            int nueva_y = tablero->balon.y + dy;

            if (nueva_x >= 0 && nueva_x < filas && nueva_y >= 0 && nueva_y < columnas &&
                es_movimiento_valido_balon(tablero, tablero->balon.x, tablero->balon.y, nueva_x, nueva_y, equipo)) {
                int puntaje = evaluar_posicion(tablero, nueva_x, nueva_y, equipo);

                if (puntaje > mejor_puntaje) {
                    mejor_puntaje = puntaje;
                    mejor_x = nueva_x;
                    mejor_y = nueva_y;
                }
            }
        }
    }

    // Realizar el mejor movimiento
    if (mejor_x != -1 && mejor_y != -1) {
        mover_balon(juego, mejor_x, mejor_y);
        imprimir_en_consola("La computadora ha realizado su movimiento.");
    } else {
        imprimir_en_consola("La computadora no puede realizar un movimiento válido.");
    }
}


bool moverpelotaComp(Juego *juego, int equipo) {
    Tablero *tablero = juego->tablero;
    int x = tablero->balon.x;
    int y = tablero->balon.y;

    int dx = (equipo == 1) ? 1 : -1; // Equipo 1 intenta bajar, equipo 2 intenta subir.
    // Primero intentamos movimiento vertical directo
    int nx = x + dx;
    int ny = y;
    if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
        if (es_movimiento_valido_balon(tablero, x, y, nx, ny, equipo)) {
            mover_balon(juego, nx, ny);
            return true;
        }
    }

    // Si no se pudo movimiento vertical directo, intentamos en diagonal (izquierda)
    nx = x + dx;
    ny = y - 1;
    if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
        if (es_movimiento_valido_balon(tablero, x, y, nx, ny, equipo)) {
            mover_balon(juego, nx, ny);
            return true;
        }
    }

    // Si no se pudo diagonal izquierda, intentamos diagonal derecha
    nx = x + dx;
    ny = y + 1;
    if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas) {
        if (es_movimiento_valido_balon(tablero, x, y, nx, ny, equipo)) {
            mover_balon(juego, nx, ny);
            return true;
        }
    }

    return false; // No se pudo mover el balón hacia adelante
}

// Intenta mover un jugador para acercarlo verticalmente al balón
bool mover_jugador_hacia_balon(Juego *juego, int equipo) {
    Tablero *tablero = juego->tablero;
    Jugador *equipo_jugadores = (equipo == 1) ? tablero->equipo_rojo : tablero->equipo_blanco;

    int bx = tablero->balon.x;
    // No nos complicamos con la distancia horizontal, solo vertical
    // Buscamos un jugador que pueda moverse una casilla hacia el balón.

    for (int i = 0; i < 5; i++) {
        Jugador *jug = &equipo_jugadores[i];
        int dx = (bx > jug->x) ? 1 : ((bx < jug->x) ? -1 : 0);
        // Intentamos moverlo una casilla hacia el balón en vertical
        if (dx != 0) {
            int nx = jug->x + dx;
            int ny = jug->y; // no movemos en y, solo verticalmente
            if (nx >= 0 && nx < filas && tablero->celdas[nx][ny].tipo == VACIO) {
                mover_jugador(juego, jug, nx, ny);
                return true;
            }
        }
    }

    // Si no pudo acercarse verticalmente, intentamos horizontalmente:
    int by = tablero->balon.y;
    for (int i = 0; i < 5; i++) {
        Jugador *jug = &equipo_jugadores[i];
        int dy = (by > jug->y) ? 1 : ((by < jug->y) ? -1 : 0);
        if (dy != 0) {
            int nx = jug->x;
            int ny = jug->y + dy;
            if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas && tablero->celdas[nx][ny].tipo == VACIO) {
                mover_jugador(juego, jug, nx, ny);
                return true;
            }
        }
    }

    return false; // no se pudo mover ningún jugador hacia el balón
}

void moverComp(Juego *juego, int equipo) {
    int posesion = verificar_posesion(juego->tablero);

    if (posesion == equipo) {
        // Tiene el balón
        if (!moverpelotaComp(juego, equipo)) {
            // No pudo mover el balón
            if (!mover_jugador_hacia_balon(juego, equipo)) {
                imprimir_en_consola("La CPU no puede hacer nada más. Fin del turno de la CPU.");
                finalizar_turno(juego);
            } else {
                // Movió un jugador
                finalizar_turno(juego);
            }
        } else {
            // Movió el balón con éxito
            finalizar_turno(juego);
        }
    } else {
        // No tiene el balón
        if (!mover_jugador_hacia_balon(juego, equipo)) {
            imprimir_en_consola("La CPU no puede hacer nada más. Fin del turno de la CPU.");
            finalizar_turno(juego);
        } else {
            finalizar_turno(juego);
        }
    }
}
