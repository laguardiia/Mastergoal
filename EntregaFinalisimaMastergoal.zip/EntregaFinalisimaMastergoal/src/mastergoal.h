
#ifndef MASTERGOAL_H_
#define MASTERGOAL_H_

#include <gtk/gtk.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <glib.h>


#define filas 13
#define columnas 11
#define modoj1vpc 1
#define modoj1j2 2
#define modopcpc 3
#define VACIO '.'
#define BALON 'B'
#define jugador_rojo 'R'
#define jugador_blanco 'W'
#define arquero_rojo 'G'
#define arquero_blanco 'g'
#define arco 'P'
extern int modo_juego;

typedef enum {
    sin_color = 0,
    rojo = 1,
    blanco = 2
} Color;

// Estructuras para representar el tablero y los elementos del juego
typedef struct {
    int x, y;
    int id;
    char tipo;
} Jugador;

typedef struct {
    int x, y;
} Balon;

typedef struct {
    int x, y;
    char tipo;                 // Tipo de ficha en la casilla
    int adyacente_rojo;       // Influencia del equipo rojo
    int adyacente_blanco;     // Influencia del equipo blanco
    bool es_area;              // Indica si es parte del área del portero
    bool es_area_chica;        // Indica si es parte del área chica
    bool es_especial;          // Indica si es una casilla especial
} Celda;


typedef enum {
    comenzando,
    En_Juego,
    procesodepase,
    reinicio,
    termino
} EstadoJuego;

typedef struct {
    Celda celdas[filas][columnas];
    Jugador equipo_rojo[5];
    Jugador equipo_blanco[5];
    Balon balon;
} Tablero;

typedef struct {
    int jugador_actual; // 1 para Jugador 1, 2 para Jugador 2
    int pases_restantes;
    bool movimiento_realizado;
} Turno;


typedef struct {
    GtkWidget *window;
    GtkWidget *grid;
    GtkWidget *buttons[filas + 2][columnas];
    Tablero *tablero;
    Jugador *jugador_seleccionado;
    int goles_rojo;
    int goles_blanco;
    GList *estadisticas;
} Juego;

extern char nombre_jugador1[20];
extern char nombre_jugador2[20];
extern GtkWidget *consola_textview;
extern Color color_jugador1;
extern Color color_jugador2;
extern Color color_jugador_inicial;
extern gboolean color_random;
extern Turno turno;
extern EstadoJuego estado_actual;
extern GtkWidget *marcador_label;

typedef struct {
    char nombre[50];
    int partidas_jugadas;
    int partidas_ganadas;
    int partidas_perdidas;
} EstadisticaJugador;

void actualizar_estadisticas(GList **estadisticas, const char *nombre, int ganado);
int ordenar_estadisticas(const void *a, const void *b);
void guardar_estadisticas(GList *estadisticas, const char *filename);
void moverComp(Juego *juego, int equipo);

void imprimir_en_consola(const char *mensaje);

// Inicialización y configuración del tablero
void inicializar_tablero(Tablero *tablero);
void cargar_tablero_desde_glade(Juego *juego, GtkBuilder *builder);
void actualizar_tablero_grafico(Juego *juego);
void reiniciar_tablero(GtkButton *button, gpointer user_data);

// Reglas y validaciones
bool area_grande_arquero(int x, int y, char tipo_portero);
bool es_casilla_especial_portero(int x, int y, Tablero *tablero, char tipo_portero);
bool posicion_adyacente(Tablero *tablero, int x, int y);
bool balon_solo(Tablero *tablero);
bool es_movimiento_valido_balon(Tablero *tablero, int origen_x, int origen_y, int destino_x, int destino_y, int equipo);

// Control del juego
int verificar_posesion(Tablero *tablero);
void mover_balon(Juego *juego, int nueva_x, int nueva_y);
void mover_jugador(Juego *juego, Jugador *jugador, int nueva_x, int nueva_y);
void mostrar_imagen_gol(Juego *juego);
void finalizar_partido(Juego *juego, int goles_rojo, int goles_blanco, int total_jugadas);
void reiniciar_posiciones_iniciales(Juego *juego);
void on_casilla_clicked(GtkButton *button, gpointer user_data);
void finalizar_turno(Juego *juego);
void actualizar_marcador(int goles_rojo, int goles_blanco);
void cambiarTurno(Juego *juego);
void reiniciar_posiciones_iniciales(Juego *juego);
void gestionar_gol(Juego *juego, int equipo);
bool es_posicion_correcta_balon(Tablero *tablero);
void salir_app(GtkButton *button, gpointer user_data);

#endif /* MASTERGOAL_H_ */
