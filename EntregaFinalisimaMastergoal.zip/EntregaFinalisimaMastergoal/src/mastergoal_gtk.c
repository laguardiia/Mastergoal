/*
 ============================================================================
 Name        : mastergoal_gtk.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in GTK+
 ============================================================================
 */



#include <gtk/gtk.h>
#include <string.h>
#include "mastergoal.h"

char nombre_jugador1[20];
char nombre_jugador2[20];
int ordenar_estadisticas(const void *a, const void *b);

GtkBuilder *builder;
GtkWidget *principal_ventana;
GtkWidget *modo_ventana;
GtkWidget *acerca_ventana;
GtkWidget *ventana_estadisticas;
GtkWidget *ventana_salida;
GtkWidget *config_ventana;
GtkWidget *ventana_tablero;
GtkWidget *estadisticas_textview;
GtkWidget *consola_textview;
GtkWidget *marcador_label;
GtkWidget *jugadores_label;

char nombre_jugador_inicial[20];

Color color_jugador1 = sin_color;
Color color_jugador2 = sin_color;
Color color_jugador_inicial = sin_color;
gboolean color_seleccionado = FALSE;
gboolean color_random = FALSE;
Turno turno = {1, 4, false};

int modo_juego = 0;  // 1 es jvpc 2 es jvj 3 es pcvpc
void actualizar_nombres_jugadores(GtkLabel *jugadores_label, const char *jugador1, Color color1, const char *jugador2, Color color2) {

    const char *color1_texto = (color1 == rojo) ? "Rojo" :
                               (color1 == blanco) ? "Blanco" : "";

    const char *color2_texto = (color2 == rojo) ? "Rojo" :
                               (color2 == blanco) ? "Blanco" : "";


    char texto[200];
    snprintf(texto, sizeof(texto), "J1: %s (%s)     J2: %s (%s)", jugador1, color1_texto, jugador2, color2_texto);


    gtk_label_set_text(jugadores_label, texto);
}


// Para salir
void on_boton_exit_clicked(GtkButton *button, gpointer user_data) {
	gtk_main_quit();
}

// Para abrir el seleccionador de modo de juego
void on_boton_iniciar_juego_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_hide(principal_ventana);
    gtk_widget_show(modo_ventana);
}

void on_boton_acercade_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_show(acerca_ventana);
}


void on_boton_volver_acerca_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_hide(acerca_ventana);
    gtk_widget_show(principal_ventana);
}


void on_modo1_clicked(GtkButton *button, gpointer user_data) {
    modo_juego = modoj1vpc;
    g_print("Modo seleccionado: Jugador 1 vs CPU.\n");
    gtk_widget_hide(modo_ventana);
    gtk_widget_show(config_ventana);
}


void on_modo2_clicked(GtkButton *button, gpointer user_data) {
    modo_juego = modoj1j2;
    g_print("Modo seleccionado: Jugador 1 vs Jugador 2.\n");
    gtk_widget_hide(modo_ventana);
    gtk_widget_show(config_ventana);
}


void on_cancel_button_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_hide(config_ventana);
    gtk_widget_show(principal_ventana);
}

void on_atras_button_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_hide(config_ventana);
    gtk_widget_show(modo_ventana);
}

void on_boton_atras_clicked(GtkButton *button, gpointer user_data) {
    gtk_widget_hide(modo_ventana);
    gtk_widget_show(principal_ventana);
}

void on_boton_atras2_clicked(GtkButton *button, gpointer user_data) {

    gtk_widget_hide(modo_ventana);
    gtk_widget_show(principal_ventana);
}

//Seleccionar color rojo
void on_boton_red_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    GtkWidget *boton_white = GTK_WIDGET(user_data);

    if (gtk_toggle_button_get_active(togglebutton)) {
        color_jugador1 = rojo;
        color_jugador2 = blanco;
        gtk_widget_set_sensitive(boton_white, FALSE);
        g_print("Jugador 1: rojo, Jugador 2: blanco\n");
    } else {
        gtk_widget_set_sensitive(boton_white, TRUE);
        g_print("Selección de rojo desactivada\n");
    }
    if (turno.jugador_actual == 1) {
        color_jugador_inicial = color_jugador1;
    } else if (turno.jugador_actual == 2) {
        color_jugador_inicial = color_jugador2;
    }
}

//Seleccionar color blanco
void on_boton_white_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    GtkWidget *boton_red = GTK_WIDGET(user_data);

    if (gtk_toggle_button_get_active(togglebutton)) {
        color_jugador1 = blanco;
        color_jugador2 = rojo;
        gtk_widget_set_sensitive(boton_red, FALSE);
        g_print("Jugador 1: blanco, Jugador 2: rojo\n");
    } else {
        gtk_widget_set_sensitive(boton_red, TRUE);
        g_print("Selección de blanco desactivada\n");
    }

    if (turno.jugador_actual == 1) {
        color_jugador_inicial = color_jugador1;
    } else if (turno.jugador_actual == 2) {
        color_jugador_inicial = color_jugador2;
    }
}

// Selección aleatoria de color
void on_random_boton_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    GtkWidget *boton_red = GTK_WIDGET(user_data);
    GtkWidget *boton_white = GTK_WIDGET(g_object_get_data(G_OBJECT(boton_red), "boton_white"));

    if (gtk_toggle_button_get_active(togglebutton)) {
        color_random = TRUE;
        srand(time(NULL));

        if (rand() % 2 == 0) {
            color_jugador1 = rojo;
            color_jugador2 = blanco;
        } else {
            color_jugador1 = blanco;
            color_jugador2 = rojo;
        }

        turno.jugador_actual = (rand() % 2) + 1; // 1 para Jugador 1, 2 para Jugador 2
        if (turno.jugador_actual == 1) {
            color_jugador_inicial = color_jugador1;
            strncpy(nombre_jugador_inicial, nombre_jugador1, sizeof(nombre_jugador_inicial) - 1);
        } else {
            color_jugador_inicial = color_jugador2;
            strncpy(nombre_jugador_inicial, nombre_jugador2, sizeof(nombre_jugador_inicial) - 1);
        }

        gtk_widget_set_sensitive(boton_red, FALSE);
        gtk_widget_set_sensitive(boton_white, FALSE);

    } else {
        color_random = FALSE;


        gtk_widget_set_sensitive(boton_red, TRUE);
        gtk_widget_set_sensitive(boton_white, TRUE);

    }
}


// j1 inicia
void on_selec_j1_clicked(GtkButton *button, gpointer user_data) {


    turno.jugador_actual = 1;  // Jugador 1 inicia
    strncpy(nombre_jugador_inicial, nombre_jugador1, sizeof(nombre_jugador_inicial) - 1);
    color_jugador_inicial = color_jugador1;

    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(consola_textview));
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);

    char inicio_texto[100];
    snprintf(inicio_texto, strlen(inicio_texto), "Inicia el juego: %s (%s)\n",
             nombre_jugador_inicial,
             color_jugador1 == rojo ? "rojo" : "blanco");
    gtk_text_buffer_insert(buffer, &end, inicio_texto, -1);
}

// j2 inicia
void on_selec_j2_clicked(GtkButton *button, gpointer user_data) {

    turno.jugador_actual = 2;  // Jugador 2 inicia
    strncpy(nombre_jugador_inicial, nombre_jugador2, sizeof(nombre_jugador_inicial) - 1);
    color_jugador_inicial = color_jugador2;

    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(consola_textview));
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);

    char inicio_texto[100];
    snprintf(inicio_texto, sizeof(inicio_texto), "Inicia el juego: %s (%s)\n",
             nombre_jugador_inicial,
             color_jugador2 == rojo ? "rojo" : "blanco");
    gtk_text_buffer_insert(buffer, &end, inicio_texto, -1);
}

// Inicia en aleatorio
void on_random_clicked(GtkButton *button, gpointer user_data) {

    turno.jugador_actual = (rand() % 2) + 1;  // Selección aleatoria: 1 para Jugador 1, 2 para Jugador 2

    // Asignar el nombre correspondiente
    if (turno.jugador_actual == 1) {
        strncpy(nombre_jugador_inicial, nombre_jugador1, sizeof(nombre_jugador_inicial) - 1);
    } else {
        strncpy(nombre_jugador_inicial, nombre_jugador2, sizeof(nombre_jugador_inicial) - 1);
    }

    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(consola_textview));
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);

    char inicio_texto[100];
    snprintf(inicio_texto, sizeof(inicio_texto), "Inicia el juego: %s (%s)\n",
             nombre_jugador_inicial,
             turno.jugador_actual == 1
                 ? (color_jugador1 == rojo ? "rojo" : "blanco")
                 : (color_jugador2 == rojo ? "rojo" : "blanco"));
    gtk_text_buffer_insert(buffer, &end, inicio_texto, -1);
}

// Para confirmar los nombres
void on_confirm_button_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *entry_nombre1 = GTK_WIDGET(gtk_builder_get_object(GTK_BUILDER(user_data), "nombre1"));
    GtkWidget *entry_nombre2 = GTK_WIDGET(gtk_builder_get_object(GTK_BUILDER(user_data), "nombre2"));

    const char *texto_nombre1 = gtk_entry_get_text(GTK_ENTRY(entry_nombre1));
    const char *texto_nombre2 = gtk_entry_get_text(GTK_ENTRY(entry_nombre2));

    strncpy(nombre_jugador1, texto_nombre1, sizeof(nombre_jugador1) - 1);
    strncpy(nombre_jugador2, texto_nombre2, sizeof(nombre_jugador2) - 1);

    if (modo_juego == modoj1vpc) {
        strncpy(nombre_jugador2, "CPU", sizeof(nombre_jugador2)-1);
    }

    // Verificar que los colores se hayan seleccionado correctamente
    if (color_jugador1 == sin_color || color_jugador2 == sin_color) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(entry_nombre1),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_CLOSE,
            "Error: Debes seleccionar un color para los jugadores.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    GtkLabel *jugadores_label = GTK_LABEL(gtk_builder_get_object(builder, "jugadores_label"));
    actualizar_nombres_jugadores(jugadores_label, nombre_jugador1, color_jugador1, nombre_jugador2, color_jugador2);


}


// Para iniciar el juego
void on_boton_aceptar_clicked(GtkButton *button, gpointer user_data) {
    Juego *juego = (Juego *)user_data;

    // Validar quién inicia según `turno.jugador_actual`
    if (turno.jugador_actual == 1) {
        strncpy(nombre_jugador_inicial, nombre_jugador1, sizeof(nombre_jugador_inicial) - 1);
        color_jugador_inicial = color_jugador1;
    } else if (turno.jugador_actual == 2) {
        strncpy(nombre_jugador_inicial, nombre_jugador2, sizeof(nombre_jugador_inicial) - 1);
        color_jugador_inicial = color_jugador2;
    } else {
        g_print("Error: No se ha seleccionado quién inicia el juego.\n");
        return;
    }
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(consola_textview));
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    char inicio_texto[100];
    snprintf(inicio_texto, sizeof(inicio_texto), "Inicia el juego: %s (%s)\n",
             nombre_jugador_inicial,
             color_jugador_inicial == rojo ? "rojo" :
             color_jugador_inicial == blanco ? "blanco" : "indefinido");
    gtk_text_buffer_insert(buffer, &end, inicio_texto, -1);

    // Establecer las configuraciones iniciales del tablero
    inicializar_tablero(juego->tablero);

    // Actualizar el gráfico del tablero y mostrarlo
    actualizar_tablero_grafico(juego);
    gtk_widget_hide(config_ventana);
    gtk_widget_show(juego->window);
}


void cargar_estadisticas(GList **estadisticas, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) return;  // Si no existe el archivo, asumimos que no hay estadísticas previas.

    EstadisticaJugador jugador;
    while (fscanf(file, "%49s %d %d %d", jugador.nombre, &jugador.partidas_jugadas,
                  &jugador.partidas_ganadas, &jugador.partidas_perdidas) == 4) {
        *estadisticas = g_list_append(*estadisticas, g_memdup2(&jugador, sizeof(EstadisticaJugador)));
    }
    fclose(file);
}


void mostrar_estadisticas_juego(GList *estadisticas) {
    estadisticas = g_list_sort(estadisticas, (GCompareFunc)ordenar_estadisticas);

    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(consola_textview));
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    gtk_text_buffer_insert(buffer, &end, "Estadisticas:\n", -1);

    for (GList *node = estadisticas; node; node = node->next) {
        EstadisticaJugador *jugador = (EstadisticaJugador *)node->data;
        char texto[200];
        snprintf(texto, sizeof(texto), "%s - Jugadas: %d, Ganadas: %d, Perdidas: %d\n",
                 jugador->nombre, jugador->partidas_jugadas, jugador->partidas_ganadas, jugador->partidas_perdidas);
        gtk_text_buffer_insert(buffer, &end, texto, -1);
    }
}

void mostrar_turno_actual(const char *jugador) {
    char mensaje[100];
    snprintf(mensaje, sizeof(mensaje), "Turno actual: %s", jugador);
    imprimir_en_consola(mensaje);
}

void finalizar_juego(const char *ganador, const char *perdedor, GList **estadisticas) {
    char mensaje[200];
    snprintf(mensaje, sizeof(mensaje), "El ganador es: %s\nEl perdedor es: %s", ganador, perdedor);
    imprimir_en_consola(mensaje);

    // Actualizar estadísticas
    actualizar_estadisticas(estadisticas, ganador, 1);
    actualizar_estadisticas(estadisticas, perdedor, 0);
}

void cerrar_estadisticas(GtkButton *button, gpointer user_data) {
    gtk_widget_hide(GTK_WIDGET(user_data));
}

void boton_estadisticas(GtkButton *button, gpointer user_data) {
    GList *estadisticas = (GList *)user_data;
    estadisticas = g_list_sort(estadisticas, (GCompareFunc)ordenar_estadisticas);

    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(estadisticas_textview));
    gtk_text_buffer_set_text(buffer, "", -1); // Limpiar el buffer antes de insertar

    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    gtk_text_buffer_insert(buffer, &end, "Probando..\n", -1);

    for (GList *node = estadisticas; node; node = node->next) {
        EstadisticaJugador *jugador = (EstadisticaJugador *)node->data;
        char texto[200];
        snprintf(texto, sizeof(texto), "%s - Jugadas: %d, Ganadas: %d, Perdidas: %d\n",
                 jugador->nombre, jugador->partidas_jugadas, jugador->partidas_ganadas, jugador->partidas_perdidas);
        gtk_text_buffer_insert(buffer, &end, texto, -1);
    }

    gtk_widget_show(ventana_estadisticas);
}


// Callback para el botón "Juego Nuevo"
void on_juego_nuevo_clicked(GtkButton *button, gpointer user_data) {
    Juego *juego = (Juego *)user_data;

    // Restablecer el estado del tablero
    inicializar_tablero(juego->tablero);
    actualizar_tablero_grafico(juego);
    juego->goles_rojo = 0;
    juego->goles_blanco = 0;
    actualizar_marcador(juego->goles_rojo, juego->goles_blanco);

    // Reiniciar variables globales
    turno.jugador_actual = 0;
    turno.pases_restantes = 0;
    turno.movimiento_realizado = false;
    nombre_jugador1[0] = '\0';
    nombre_jugador2[0] = '\0';
    nombre_jugador_inicial[0] = '\0';
    color_jugador1 = sin_color;
    color_jugador2 = sin_color;
    color_jugador_inicial = sin_color;
    color_random = FALSE;

    // Limpiar las entradas de texto de los nombres
    GtkEntry *entry_nombre1 = GTK_ENTRY(gtk_builder_get_object(builder, "nombre1"));
    GtkEntry *entry_nombre2 = GTK_ENTRY(gtk_builder_get_object(builder, "nombre2"));
    if (entry_nombre1 && entry_nombre2) {
        gtk_entry_set_text(entry_nombre1, "");
        gtk_entry_set_text(entry_nombre2, "");
    }

    // Restablecer botones de selección de colores
    GtkToggleButton *boton_red = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "boton_red"));
    GtkToggleButton *boton_white = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "boton_white"));
    GtkToggleButton *random_boton = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "random_boton"));
    if (boton_red && boton_white && random_boton) {
        gtk_toggle_button_set_active(boton_red, FALSE);
        gtk_toggle_button_set_active(boton_white, FALSE);
        gtk_toggle_button_set_active(random_boton, FALSE);
        gtk_widget_set_sensitive(GTK_WIDGET(boton_red), TRUE);
        gtk_widget_set_sensitive(GTK_WIDGET(boton_white), TRUE);
    }

    // Restablecer botones de selección de quién inicia
    GtkToggleButton *selec_j1 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "selec_j1"));
    GtkToggleButton *selec_j2 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "selec_j2"));
    GtkToggleButton *random_inicio = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "random"));

    if (selec_j1 && selec_j2 && random_inicio) {
        gtk_toggle_button_set_active(selec_j1, FALSE);
        gtk_toggle_button_set_active(selec_j2, FALSE);
        gtk_toggle_button_set_active(random_inicio, FALSE);
    }

    // Limpiar label de jugadores
    GtkLabel *jugadores_label = GTK_LABEL(gtk_builder_get_object(builder, "jugadores_label"));
    gtk_label_set_text(jugadores_label, "");

    // Limpiar el textview de la consola
    if (consola_textview) {
        GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(consola_textview));
        gtk_text_buffer_set_text(buffer, "", -1);
    }

    // Ocultar el tablero y mostrar el menú principal
    gtk_widget_hide(juego->window);
    gtk_widget_show(principal_ventana);
}


int main(int argc, char *argv[]) {
    Juego juego = {0};

    gtk_init(&argc, &argv);

    GList *estadisticas = NULL;
    cargar_estadisticas(&estadisticas, "estadisticas.txt");


    // Cargamos la interfaz
    builder = gtk_builder_new();
    if (!gtk_builder_add_from_file(builder, "/home/laguardia/eclipse-workspace/EntregaFinalisimaMastergoal/InterfazMaster.glade", NULL)) {
        g_printerr("ERROOOR al cargar el glade\n");
        return 1;
    }

    // Cargar estadísticas desde el archivo
    cargar_estadisticas(&juego.estadisticas, "estadisticas.txt");

    // Cargar las ventanas principales
    principal_ventana = GTK_WIDGET(gtk_builder_get_object(builder, "principal_ventana"));
    modo_ventana = GTK_WIDGET(gtk_builder_get_object(builder, "modo_ventana"));
    acerca_ventana = GTK_WIDGET(gtk_builder_get_object(builder, "acerca_ventana"));
    ventana_estadisticas = GTK_WIDGET(gtk_builder_get_object(builder, "Ventana_Estadisticas"));
    ventana_salida = GTK_WIDGET(gtk_builder_get_object(builder, "Salida"));
    config_ventana = GTK_WIDGET(gtk_builder_get_object(builder, "config_ventana"));


    // Al cargar el tablero en el main
    consola_textview = GTK_WIDGET(gtk_builder_get_object(builder, "consola_textview"));

    juego.tablero = g_new0(Tablero, 1);
    inicializar_tablero(juego.tablero);
    juego.window = GTK_WIDGET(gtk_builder_get_object(builder, "cancha"));
    if (!juego.window) {
        g_printerr("Error: No se pudo cargar el widget 'tablero'.\n");
        return 1;
    }
    gtk_widget_hide(juego.window);  // Ocultar main_tablero para que no aparezca al iniciar
    g_signal_connect(juego.window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // Conectar widgets adicionales en el tablero y actualizar el marcador y tiempo
    marcador_label = GTK_WIDGET(gtk_builder_get_object(builder, "marcador_label"));
    consola_textview = GTK_WIDGET(gtk_builder_get_object(builder, "consola_textview"));
    actualizar_marcador(0, 0);

    cargar_tablero_desde_glade(&juego, builder);

    // Configurar el botón "Volver" en la ventana "Acerca de"
    GtkWidget *boton_volver_acerca = GTK_WIDGET(gtk_builder_get_object(builder, "volver_acerca"));
    g_signal_connect(boton_volver_acerca, "clicked", G_CALLBACK(on_boton_volver_acerca_clicked), NULL);


    // Conectar botones en config_ventana
    GtkWidget *cancel_button = GTK_WIDGET(gtk_builder_get_object(builder, "cancel_button")); //este uso
    g_signal_connect(cancel_button, "clicked", G_CALLBACK(on_cancel_button_clicked), NULL);

    GtkWidget *boton_atras = GTK_WIDGET(gtk_builder_get_object(builder, "boton_atras"));
    g_signal_connect(boton_atras, "clicked", G_CALLBACK(on_boton_atras_clicked), modo_ventana);


    // Configurar botones en modo_juego
    GtkWidget *modo2 = GTK_WIDGET(gtk_builder_get_object(builder, "modo2"));
    g_signal_connect(modo2, "clicked", G_CALLBACK(on_modo2_clicked), NULL);

    GtkWidget *modo1 = GTK_WIDGET(gtk_builder_get_object(builder, "modo1"));
    g_signal_connect(modo1, "clicked", G_CALLBACK(on_modo1_clicked), NULL);


    GtkWidget *salir_button = GTK_WIDGET(gtk_builder_get_object(builder, "salir_button"));
    g_signal_connect(salir_button, "clicked", G_CALLBACK(on_boton_exit_clicked), NULL);

    // Conectar los botones del menú principal
    GtkWidget *boton_iniciar = GTK_WIDGET(gtk_builder_get_object(builder, "iniciar_juego"));
    GtkWidget *boton_acercade = GTK_WIDGET(gtk_builder_get_object(builder, "Acercade"));
    GtkWidget *boton_exit = GTK_WIDGET(gtk_builder_get_object(builder, "exit"));

    g_signal_connect(boton_iniciar, "clicked", G_CALLBACK(on_boton_iniciar_juego_clicked), NULL);
    g_signal_connect(boton_acercade, "clicked", G_CALLBACK(on_boton_acercade_clicked), NULL);
    g_signal_connect(boton_exit, "clicked", G_CALLBACK(on_boton_exit_clicked), NULL);
    g_signal_connect(principal_ventana, "destroy", G_CALLBACK (gtk_main_quit), NULL);

    // Configurar botones de color en config_ventana
    GtkWidget *boton_red = GTK_WIDGET(gtk_builder_get_object(builder, "boton_red"));
    GtkWidget *boton_white = GTK_WIDGET(gtk_builder_get_object(builder, "boton_white"));
    GtkWidget *random_boton = GTK_WIDGET(gtk_builder_get_object(builder, "random_boton"));
    g_object_set_data(G_OBJECT(boton_red), "boton_white", boton_white);
    g_signal_connect(boton_red, "toggled", G_CALLBACK(on_boton_red_toggled), boton_white);
    g_signal_connect(boton_white, "toggled", G_CALLBACK(on_boton_white_toggled), boton_red);
    g_signal_connect(random_boton, "toggled", G_CALLBACK(on_random_boton_toggled), boton_red);

    // Configurar botones de window_orden
    GtkWidget *boton_aceptar = GTK_WIDGET(gtk_builder_get_object(builder, "boton_aceptar")); //est uso
    GtkWidget *selec_j1 = GTK_WIDGET(gtk_builder_get_object(builder, "selec_j1"));
    GtkWidget *selec_j2 = GTK_WIDGET(gtk_builder_get_object(builder, "selec_j2"));
    GtkWidget *random = GTK_WIDGET(gtk_builder_get_object(builder, "random"));

    g_signal_connect(boton_aceptar, "clicked", G_CALLBACK(on_boton_aceptar_clicked), &juego);
    g_signal_connect(selec_j1, "clicked", G_CALLBACK(on_selec_j1_clicked), NULL);
    g_signal_connect(selec_j2, "clicked", G_CALLBACK(on_selec_j2_clicked), NULL);
    g_signal_connect(random, "clicked", G_CALLBACK(on_random_clicked), NULL);

    ventana_estadisticas = GTK_WIDGET(gtk_builder_get_object(builder, "ventana_estadisticas"));
    estadisticas_textview = GTK_WIDGET(gtk_builder_get_object(builder, "estadisticas_textview"));

    GtkWidget *estadisticas_boton = GTK_WIDGET(gtk_builder_get_object(builder, "estadisticas_boton"));
    g_signal_connect(estadisticas_boton, "clicked", G_CALLBACK(boton_estadisticas), estadisticas);

    // Conectar botón para cerrar la ventana de estadísticas
    GtkWidget *cerrar_estadisticas_button = GTK_WIDGET(gtk_builder_get_object(builder, "cerrar_estadisticas"));
    g_signal_connect(cerrar_estadisticas_button, "clicked", G_CALLBACK(cerrar_estadisticas), ventana_estadisticas);

    GtkWidget *juego_nuevo_button = GTK_WIDGET(gtk_builder_get_object(builder, "juego_nuevo"));
    g_signal_connect(juego_nuevo_button, "clicked", G_CALLBACK(on_juego_nuevo_clicked), &juego);

    GtkLabel *jugadores_label = GTK_LABEL(gtk_builder_get_object(builder, "jugadores_label"));
    actualizar_nombres_jugadores(jugadores_label, nombre_jugador1, color_jugador1, nombre_jugador2, color_jugador2);


    // Mostrar la ventana principal
    gtk_widget_show(principal_ventana);

    gtk_main();

    guardar_estadisticas(juego.estadisticas, "estadisticas.txt");

    // Liberar la lista GList
    g_list_free_full(juego.estadisticas, g_free);

    // Liberar recursos
    g_free(juego.tablero);
    g_object_unref(builder);
    return 0;
}
