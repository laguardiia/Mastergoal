/*
 * mastergoal_gtk.c
 *
 *  Created on: 7 nov. 2024
 *      Author: lp1
 */

#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "mastergoal.h"
static int puntajeX = 0; // Puntaje del Jugador X
static int puntajeO = 0; // Puntaje del Jugador O




void graficarTableroEnGrid(GtkGrid *grid, char cancha[tamY][tamX]);
void cambiaTurno(void);




char cancha[tamY][tamX];        // Tablero del juego
jugador team_rojo[5];           // Equipo rojo
jugador team_blanco[5];         // Equipo blanco
pelota pelota_juego; // La pelota
extern int turno;               // Turno actual (declarado en otro archivo)



GtkBuilder *builder; // identificador del repositorio de interfaz con el usuario abierto
GObject *window;	// identificador de la ventana principal de la aplicación
GObject *dialogAyuda;// identificador de la ventana de diálogo de ayuda al juego
GObject *dialogAcerca;// identificador de la ventana de diálogo de Acerca de
GObject *dialogEstadisticas; //identificador de la ventana de dialogo de Estadisticas
GObject *dialogAbrir;	// identificador de la ventana de diálogo de Abrir
GObject *dialogSalvar;// identificador de la ventana de diálogo de Salvar juego
GObject *dialogSobreescribir;
GObject *iBoton1;		// identificadores de los botones
GObject *BotonModoJuego;
GObject *idEtiquetaInfoBar;	// identificador de la etiqueta del info bar
GObject *menu_archivo_nuevo;	// identificador del item nuevo del menú archivo

GtkFileFilter *filtroArchivo;

int partidaTerminada;	// Bandera que indica si la partida terminó (1)
int partidaIniciada;	// bandera que indica si se inició una partida

#define HUMANO_VS_HUMANO		1
#define COMPUTADORA_VS_HUMANO	2
int modoJuego = HUMANO_VS_HUMANO;

EstadisticaJugador jugador1, jugador2;

int salvado;	// bandera que indica si el juego ya está salvado
int tengoNombre;// bandera que indica si el nombre del archivo está ya definido
gchar filename[200];	// espacio de memoria para el nombre del archivo




void on_tablero_button_clicked(GtkButton *button, gpointer user_data) {
    int position = GPOINTER_TO_INT(user_data);
    int i = position / tamX; // Fila
    int j = position % tamX; // Columna

    static int piezaSeleccionada = 0; // 0: No seleccionada, 1: Jugador, 2: Pelota
    static int seleccionFila = -1;    // Fila de la selección previa
    static int seleccionColumna = -1; // Columna de la selección previa

    g_print("Clic en la celda (%d, %d)\n", i, j);

    if (piezaSeleccionada == 0) {
        // Selección inicial
        if (turno == JUGADOR_X && cancha[i][j] == 'R') {
            piezaSeleccionada = 1; // Jugador
            seleccionFila = i;
            seleccionColumna = j;
            g_print("Jugador X seleccionó pieza en (%d, %d)\n", i, j);
        } else if (turno == JUGADOR_O && cancha[i][j] == 'B') {
            piezaSeleccionada = 1; // Jugador
            seleccionFila = i;
            seleccionColumna = j;
            g_print("Jugador O seleccionó pieza en (%d, %d)\n", i, j);
        } else if (cancha[i][j] == '0') { // Pelota
            piezaSeleccionada = 2;
            seleccionFila = i;
            seleccionColumna = j;
            g_print("Pelota seleccionada en (%d, %d)\n", i, j);
        } else {
            g_print("Selección inválida en (%d, %d)\n", i, j);
        }
    } else {
        // Movimiento
        if (piezaSeleccionada == 1) {
            // Movimiento del jugador
            if ((turno == JUGADOR_X && moverJugador(cancha, &team_rojo[0], i, j)) ||
                (turno == JUGADOR_O && moverJugador(cancha, &team_blanco[0], i, j))) {
                g_print("Jugador movió pieza a (%d, %d)\n", i, j);
            } else {
                g_print("Movimiento inválido para la pieza seleccionada\n");
            }
        } else if (piezaSeleccionada == 2) {
            // Movimiento de la pelota
            if (moverPelota(cancha, &pelota_juego, i, j, turno)) {
                g_print("Pelota movida a (%d, %d)\n", i, j);
            } else {
                g_print("Movimiento inválido para la pelota\n");
            }
        }

        // Reseteo de la selección
        piezaSeleccionada = 0;
        seleccionFila = -1;
        seleccionColumna = -1;

        // Verificar gol
        if (verificarGol(&pelota_juego)) {
            const char *nombreGanador = (turno == JUGADOR_X) ? "Jugador X" : "Jugador O";
            const char *nombrePerdedor = (turno == JUGADOR_X) ? "Jugador O" : "Jugador X";

            actualizarEstadisticas("estadisticas.dat", nombreGanador, 1);
            actualizarEstadisticas("estadisticas.dat", nombrePerdedor, -1);

            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                       GTK_BUTTONS_OK, "¡Gol!");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);

            inicializarTablero(cancha, team_rojo, team_blanco, 5, &pelota_juego);
        }

        // Actualizar el turno
        cambiaTurno();
    }

    // Actualizar tablero gráfico
    graficarTableroEnGrid(GTK_GRID(gtk_builder_get_object(builder, "grid_tablero")), cancha);
}





void cambiaTurno(void) {
    turno = 1 - turno; // Cambia entre 0 y 1

    const char *mensaje = (turno == JUGADOR_X) ? "Turno: Jugador X" : "Turno: Jugador O";
    GtkWidget *lblTurno = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_turno"));
    if (lblTurno) {
        gtk_label_set_text(GTK_LABEL(lblTurno), mensaje);
    }

    g_print("%s\n", mensaje);
}




void graficarTableroEnGrid(GtkGrid *grid, char cancha[tamY][tamX]) {

    GList *children = gtk_container_get_children(GTK_CONTAINER(grid));
    for (GList *iter = children; iter != NULL; iter = iter->next) {
        gtk_widget_destroy(GTK_WIDGET(iter->data));
    }
    g_list_free(children);

    for (int i = 0; i < tamY; i++) {
        for (int j = 0; j < tamX; j++) {
        	GtkWidget *celda;
        	char label_text[2] = {cancha[i][j], '\0'};  // Convertimos el carácter en cadena

        	// Crear un botón para cada posición del tablero
        	celda = gtk_button_new_with_label(label_text);

        	// Asocia el clic de cada celda con un callback
        	g_signal_connect(celda, "clicked", G_CALLBACK(on_tablero_button_clicked), GINT_TO_POINTER((i * tamX) + j));

        	// Añade el botón al grid en la posición correspondiente
        	gtk_grid_attach(GTK_GRID(grid), celda, j, i, 1, 1);



            if (cancha[i][j] == 'R') {
                gtk_widget_set_name(celda, "jugador_rojo");  // CSS para rojo
            } else if (cancha[i][j] == 'B') {
                gtk_widget_set_name(celda, "jugador_blanco");  // CSS para blanco
            } else if (cancha[i][j] == '.') {
                gtk_widget_set_name(celda, "punto");  // CSS para puntos
            } else if (cancha[i][j] == '=') {
                gtk_widget_set_name(celda, "pared");  // CSS para pared
            }else if (cancha[i][j] == '0') {
                gtk_widget_set_name(celda, "pelota");  // CSS para pelota
            }
            // Añadir el label al grid en la posición correspondiente
            gtk_grid_attach(grid, celda, j, i, 1, 1);
        }
    }

    // Mostrar todos los widgets dentro del grid
    gtk_widget_show_all(GTK_WIDGET(grid));
}

void mostrarVentanaConfiguracion(GtkButton *button, gpointer user_data) {
    GtkWidget *ventanaConfig = GTK_WIDGET(gtk_builder_get_object(builder, "config_ventana"));
    if (ventanaConfig) {
        gtk_widget_show_all(ventanaConfig); // Muestra la ventana de configuración
    } else {
        g_critical("No se pudo encontrar la ventana de configuración en el archivo Glade.");
    }
}

void aceptarConfiguracion(GtkButton *button, gpointer user_data) {
    GtkBuilder *builder = GTK_BUILDER(user_data);

    // Obtener las entradas de texto
    GtkEntry *entryJugadorX = GTK_ENTRY(gtk_builder_get_object(builder, "nombre1_entrada"));
    GtkEntry *entryJugadorO = GTK_ENTRY(gtk_builder_get_object(builder, "nombre2_entrada"));

    if (entryJugadorX && entryJugadorO) {
        const char *nombreJugadorX = gtk_entry_get_text(entryJugadorX);
        const char *nombreJugadorO = gtk_entry_get_text(entryJugadorO);

        if (g_strcmp0(nombreJugadorX, "") == 0 || g_strcmp0(nombreJugadorO, "") == 0) {
            // Mostrar advertencia si alguno de los nombres está vacío
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING,
                                                       GTK_BUTTONS_OK, "Por favor, complete los nombres de ambos jugadores.");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            return; // Salir de la función sin cerrar la ventana
        }

        // Configurar los nombres de los capitanes de ambos equipos
        strncpy(team_rojo[0].nombre, nombreJugadorX, sizeof(team_rojo[0].nombre) - 1);
        strncpy(team_blanco[0].nombre, nombreJugadorO, sizeof(team_blanco[0].nombre) - 1);

        // Actualizar las etiquetas en la ventana principal
        GtkLabel *labelJugadorX = GTK_LABEL(gtk_builder_get_object(builder, "label_jugador1_id"));
        GtkLabel *labelJugadorO = GTK_LABEL(gtk_builder_get_object(builder, "label_jugador2_id"));

        gchar *textoJugadorX = g_strdup_printf("Jugador X: %s", nombreJugadorX);
        gchar *textoJugadorO = g_strdup_printf("Jugador O: %s", nombreJugadorO);

        if (labelJugadorX) {
            gtk_label_set_text(labelJugadorX, textoJugadorX);
        }

        if (labelJugadorO) {
            gtk_label_set_text(labelJugadorO, textoJugadorO);
        }

        g_free(textoJugadorX);
        g_free(textoJugadorO);
    } else {
        g_critical("No se pudieron obtener las entradas de los nombres.");
        return;
    }

    // Verificar la configuración de colores y quién inicia
    GtkToggleButton *colorBlanco = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "color_blanco"));
    GtkToggleButton *colorRojo = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "color_rojo"));
    GtkToggleButton *empiezaJugador1 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "inicia_j1"));
    GtkToggleButton *empiezaJugador2 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "inicia_j2"));
    GtkToggleButton *empiezaAleatorio = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "aleatorio"));

    const gchar *colorSeleccionado = gtk_toggle_button_get_active(colorBlanco) ? "Blanco" : "Rojo";
    const gchar *jugadorInicial;

    if (gtk_toggle_button_get_active(empiezaJugador1)) {
        jugadorInicial = "Jugador 1";
    } else if (gtk_toggle_button_get_active(empiezaJugador2)) {
        jugadorInicial = "Jugador 2";
    } else if (gtk_toggle_button_get_active(empiezaAleatorio)) {
        jugadorInicial = (rand() % 2 == 0) ? "Jugador 1" : "Jugador 2";
    } else {
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING,
                                                   GTK_BUTTONS_OK, "Por favor, seleccione quién inicia.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    // Actualizar etiquetas de configuración en la ventana principal
    GtkLabel *labelColor = GTK_LABEL(gtk_builder_get_object(builder, "label_color_id"));
    GtkLabel *labelInicia = GTK_LABEL(gtk_builder_get_object(builder, "label_inicia_id"));

    gchar *textoColor = g_strdup_printf("Color elegido: %s", colorSeleccionado);
    gchar *textoInicia = g_strdup_printf("Inicia: %s", jugadorInicial);

    if (labelColor) {
        gtk_label_set_text(labelColor, textoColor);
    }

    if (labelInicia) {
        gtk_label_set_text(labelInicia, textoInicia);
    }

    g_free(textoColor);
    g_free(textoInicia);

    // Ocultar la ventana de configuración
    GtkWidget *ventanaConfig = GTK_WIDGET(gtk_builder_get_object(builder, "config_ventana"));
    if (ventanaConfig) {
        gtk_widget_hide(ventanaConfig);
    }

    // Iniciar el juego
    iniciarJuego(builder);
}




void iniciarJuego(GtkBuilder *builder) {
    // Inicializa el tablero
    inicializarTablero(cancha, team_rojo, team_blanco, 5, &pelota_juego);

    // Reinicia los puntajes
    puntajeX = 0;
    puntajeO = 0;

    // Actualiza los labels de puntaje
    GtkWidget *lblPuntajeX = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_puntaje_x"));
    GtkWidget *lblPuntajeO = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_puntaje_o"));
    if (lblPuntajeX) gtk_label_set_text(GTK_LABEL(lblPuntajeX), "Jugador X: 0");
    if (lblPuntajeO) gtk_label_set_text(GTK_LABEL(lblPuntajeO), "Jugador O: 0");

    // Configura el turno inicial
    turno = JUGADOR_X;
    GtkWidget *lblTurno = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_turno"));
    if (lblTurno) gtk_label_set_text(GTK_LABEL(lblTurno), "Turno: Jugador X");

    // Actualiza el tablero gráfico
    GtkWidget *grid = GTK_WIDGET(gtk_builder_get_object(builder, "grid_tablero"));
    if (grid) {
        graficarTableroEnGrid(GTK_GRID(grid), cancha);
    }

    g_print("El juego ha sido iniciado.\n");
}



static void on_button_clicked(GtkWidget *button, gpointer user_data) {
    const char *label = gtk_button_get_label(GTK_BUTTON(button));
    g_print("Button %s clicked\n", label);
}

// Función para cerrar la ventana
static void on_button_clicked_close(GtkWidget *widget, GtkWidget *window) {
    gtk_window_close(GTK_WINDOW(window));
}


void on_iniciar_partida_clicked(GtkButton *button, gpointer user_data) {
    GtkBuilder *builder = GTK_BUILDER(user_data);

    // Cargar la ventana de configuración
    GtkWidget *config_ventana = GTK_WIDGET(gtk_builder_get_object(builder, "config_ventana"));

    // Mostrar la ventana de configuración
    gtk_widget_show(config_ventana);
}


void on_config_ventana_closed(GtkWidget *widget, gpointer user_data) {
    GtkBuilder *builder = GTK_BUILDER(user_data);



    // 2. Obtener las selecciones de color
    GtkToggleButton *color_blanco = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "color_blanco"));
    GtkToggleButton *color_rojo = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "color_rojo"));

    const gchar *color_seleccionado;
    if (gtk_toggle_button_get_active(color_blanco)) {
        color_seleccionado = "Blanco";
    } else if (gtk_toggle_button_get_active(color_rojo)) {
        color_seleccionado = "Rojo";
    } else {
        color_seleccionado = "No seleccionado";
    }

    // 3. Obtener quién empieza, incluyendo la opción aleatoria
    GtkToggleButton *empieza_jugador1 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "inicia_j1"));
    GtkToggleButton *empieza_jugador2 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "inicia_j2"));
    GtkToggleButton *empieza_aleatorio = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "aleatorio"));

    const gchar *jugador_inicial;
    if (gtk_toggle_button_get_active(empieza_jugador1)) {
        jugador_inicial = "Jugador1";
    } else if (gtk_toggle_button_get_active(empieza_jugador2)) {
        jugador_inicial = "Jugador2";
    } else if (gtk_toggle_button_get_active(empieza_aleatorio)) {
        // Selección aleatoria entre Jugador1 y Jugador2
        srand(time(NULL));  // Inicializa el generador de números aleatorios
        jugador_inicial = (rand() % 2 == 0) ? "Jugador1" : "Jugador2";
    } else {
        jugador_inicial = "No seleccionado";
    }

    // 4. Actualizar las etiquetas en la ventana principal

    GtkLabel *label_color = GTK_LABEL(gtk_builder_get_object(builder, "label_color_id"));
    GtkLabel *label_inicia = GTK_LABEL(gtk_builder_get_object(builder, "label_inicia_id"));


    gchar *texto_color = g_strdup_printf("Color elegido: %s", color_seleccionado);
    gchar *texto_inicia = g_strdup_printf("Inicia: %s", jugador_inicial);


    gtk_label_set_text(label_color, texto_color);
    gtk_label_set_text(label_inicia, texto_inicia);

    g_free(texto_color);
    g_free(texto_inicia);
}

void on_boton_aceptar_clicked(GtkButton *button, gpointer user_data) {
    GtkBuilder *builder = GTK_BUILDER(user_data);

    // 1. Obtener los GtkEntry y verificar que no estén vacíos
    GtkEntry *entry1 = GTK_ENTRY(gtk_builder_get_object(builder, "nombre1_entrada"));
    GtkEntry *entry2 = GTK_ENTRY(gtk_builder_get_object(builder, "nombre2_entrada"));

    const gchar *nombre_jugador1 = gtk_entry_get_text(entry1);
    const gchar *nombre_jugador2 = gtk_entry_get_text(entry2);
    g_print(" Mensaje de depuración El nombre 1 es:%s y el nombre 22 es:%s", nombre_jugador1,nombre_jugador2);



    if (g_strcmp0(nombre_jugador1, "") == 0 || g_strcmp0(nombre_jugador2, "") == 0) {
        // Mostrar advertencia si alguno de los nombres está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING,
                                                   GTK_BUTTONS_OK, "Por favor, complete los nombres de ambos jugadores.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return; // Salir de la función sin cerrar la ventana
    }

    // 2. Verificar que se haya seleccionado un color
    GtkToggleButton *color_blanco = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "color_blanco"));
    GtkToggleButton *color_rojo = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "color_rojo"));

    if (!gtk_toggle_button_get_active(color_blanco) && !gtk_toggle_button_get_active(color_rojo)) {
        // Mostrar advertencia si no se ha seleccionado un color
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING,
                                                   GTK_BUTTONS_OK, "Por favor, seleccione un color.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return; // Salir de la función sin cerrar la ventana
    }

    // 3. Verificar que se haya seleccionado quién empieza
    GtkToggleButton *empieza_jugador1 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "inicia_j1"));
    GtkToggleButton *empieza_jugador2 = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "inicia_j2"));
    GtkToggleButton *empieza_aleatorio = GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "aleatorio"));

    if (!gtk_toggle_button_get_active(empieza_jugador1) &&
        !gtk_toggle_button_get_active(empieza_jugador2) &&
        !gtk_toggle_button_get_active(empieza_aleatorio)) {
        // Mostrar advertencia si no se ha seleccionado quién empieza
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING,
                                                   GTK_BUTTONS_OK, "Por favor, seleccione quién empieza.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return; // Salir de la función sin cerrar la ventana
    }
    // 4. Actualizar las etiquetas en la ventana principal
        GtkLabel *label_jugador1 = GTK_LABEL(gtk_builder_get_object(builder, "label_jugador1_id"));
        GtkLabel *label_jugador2 = GTK_LABEL(gtk_builder_get_object(builder, "label_jugador2_id"));

        gchar *texto_jugador1 = g_strdup_printf("Jugador1: %s", nombre_jugador1);
        gchar *texto_jugador2 = g_strdup_printf("Jugador2: %s", nombre_jugador2);


        gtk_label_set_text(label_jugador1, texto_jugador1);
        gtk_label_set_text(label_jugador2, texto_jugador2);


        // Liberar la memoria de los textos construidos
        g_free(texto_jugador1);
        g_free(texto_jugador2);
    // Si todos los campos están completos, cerrar la ventana de configuración
    GtkWidget *config_ventana = GTK_WIDGET(gtk_builder_get_object(builder, "config_ventana"));
    gtk_widget_destroy(config_ventana);

    // Llamar al callback de cierre para actualizar la ventana principal
    on_config_ventana_closed(config_ventana, user_data);
}


/*
 * función de callback para el item Acerca de del menú Ayuda
 * Parámetros:
 * 	Los estandar de un callback
 * Retorno:
 *  Ninguno
 */
static void mostrar_acerca(GtkWidget *widget, gpointer data) {
	gtk_dialog_run(GTK_DIALOG(dialogAcerca) );// mostramos la ventana de diálogo
	gtk_widget_hide(GTK_WIDGET(dialogAcerca) );	// escondemos la ventana
}

static void mostrar_estadisticas(GtkWidget *widget, gpointer data) {
	gtk_widget_show(GTK_WIDGET(dialogEstadisticas));
    GtkTextView *textView = GTK_TEXT_VIEW(gtk_builder_get_object(builder, "estadisticas_texto"));
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(textView);

    FILE *file = fopen("estadisticas.dat", "rb");
    if (!file) {
        gtk_text_buffer_set_text(buffer, "No hay estadísticas guardadas.", -1);
        return;
    }

    EstadisticaJugador jugador;
    char texto[256];
    gtk_text_buffer_set_text(buffer, "", -1);
    int hayEstadisticas = 0;

    while (fread(&jugador, sizeof(EstadisticaJugador), 1, file)) {
        hayEstadisticas = 1;
        snprintf(texto, sizeof(texto), "Jugador: %s\nGanados: %d\nPerdidos: %d\nEmpatados: %d\n\n",
                 jugador.nombre, jugador.partidosGanados, jugador.partidosPerdidos, jugador.partidosEmpatados);
        gtk_text_buffer_insert_at_cursor(buffer, texto, -1);
    }

    fclose(file);

    if (!hayEstadisticas) {
        gtk_text_buffer_set_text(buffer, "No hay estadísticas disponibles.", -1);
    }

    gtk_widget_show(GTK_WIDGET(dialogEstadisticas));
}
void mostrarEstadisticas(GtkButton *button, gpointer user_data) {
    FILE *fp = fopen("estadisticas.dat", "rb");
    if (!fp) {
        // Muestra un mensaje si no se encuentra el archivo
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "No se encontró el archivo de estadísticas.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    // Crea un cuadro de diálogo para mostrar las estadísticas
    GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                               GTK_BUTTONS_OK, "Estadísticas de los jugadores:");
    char buffer[256];
    EstadisticaJugador jugador;

    // Lee el archivo y añade la información al cuadro de diálogo
    while (fread(&jugador, sizeof(EstadisticaJugador), 1, fp)) {
        snprintf(buffer, sizeof(buffer),
                 "Jugador: %s\nGanados: %d\nPerdidos: %d\nEmpatados: %d\n\n",
                 jugador.nombre, jugador.partidosGanados, jugador.partidosPerdidos, jugador.partidosEmpatados);
        gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(dialog), "%s", buffer);
    }

    fclose(fp);

    // Muestra el cuadro de diálogo
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

void reiniciarJuego(GtkButton *button, gpointer user_data) {
    // Reinicia el estado del tablero y variables del juego
    inicializarTablero(cancha, team_rojo, team_blanco, 5, &pelota_juego);

    // Reinicia los puntajes
    puntajeX = 0;
    puntajeO = 0;

    // Actualiza los marcadores en la interfaz
    GtkWidget *lblPuntajeX = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_puntaje_x"));
    GtkWidget *lblPuntajeO = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_puntaje_o"));

    if (lblPuntajeX) gtk_label_set_text(GTK_LABEL(lblPuntajeX), "Jugador X: 0");
    if (lblPuntajeO) gtk_label_set_text(GTK_LABEL(lblPuntajeO), "Jugador O: 0");

    // Reinicia el turno
    turno = JUGADOR_X;
    GtkWidget *lblTurno = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_turno"));
    if (lblTurno) gtk_label_set_text(GTK_LABEL(lblTurno), "Turno: Jugador X");

    // Actualiza el tablero gráfico
    GtkWidget *grid = GTK_WIDGET(gtk_builder_get_object(builder, "grid_tablero"));
    if (grid) {
        graficarTableroEnGrid(GTK_GRID(grid), cancha);
    }

    g_print("El juego ha sido reiniciado.\n");
}




int main(int argc, char *argv[]) {
//
	//cargarEstadisticas("estadisticas.txt");

	GObject *acerca_boton;	// identificador del objeto menu item acerca
	GObject *estadisticas_boton; //identificador del objeto menu item estadisticas
	GObject *salir_boton;
	GObject *salir_menu;

	char label[5]; // Para los números de los botones
	GtkWidget *boton;
	GtkWidget *grid;


	guint ret;

	GError *error = NULL;

	gtk_init(&argc, &argv);

	/* Construimos la interfaz a partir del archivo generado por el GLADE */
	builder = gtk_builder_new();
	ret = gtk_builder_add_from_file(builder, "interfazMastergoal.glade", &error);

	if (ret == 0) {
		g_print("Error en la función gtk_builder_add_from_file:\n%s",
				error->message);
		return 1;
	}

	g_free(error);

	/* Conectamos las señales a los callbacks correspondientes */
	// cuadros de diálogo
	dialogAcerca = gtk_builder_get_object(builder, "acerca_window");// leemos la ventana de diálogo de ayuda para el juego

	dialogEstadisticas = gtk_builder_get_object(builder, "estadisticas_window"); //leemos la ventana de dialogo de estadisticas del juego

	// ventana principal
	window = gtk_builder_get_object(builder, "principal_ventana");
	g_signal_connect(window, "destroy", G_CALLBACK (gtk_main_quit), NULL);	// cuando la ventana es destruida se sale del programa

	grid = GTK_WIDGET(gtk_builder_get_object(builder, "grid_tablero"));


    for (int i = 0; i < tamY; i++) {
        for (int j = 0; j < tamX; j++) {
            snprintf(label, sizeof(label), "	"); // Crear etiquetas para los botones
            boton = gtk_button_new_with_label(label);
            g_signal_connect(boton, "clicked", G_CALLBACK(on_button_clicked), NULL);
            gtk_grid_attach(GTK_GRID(grid), boton, j, i, 1, 1); // Añadir botón al grid
            gtk_widget_set_sensitive (GTK_WIDGET(boton), FALSE);
        }
    }

	// leemos los botones y le asignamos sus callbacks correspondientes

    GtkWidget *modo_jvc_boton = GTK_WIDGET(gtk_builder_get_object(builder, "modo_jvc_boton"));
    GtkWidget *modo_cvc_boton = GTK_WIDGET(gtk_builder_get_object(builder, "modo_cvc_boton"));
    GtkWidget *modo_jvj_boton = GTK_WIDGET(gtk_builder_get_object(builder, "modo_jvj_boton"));


	// opciones de menú

    acerca_boton = gtk_builder_get_object(builder, "acerca_boton");
	g_signal_connect(acerca_boton, "activate", G_CALLBACK (mostrar_acerca), NULL);

	estadisticas_boton = gtk_builder_get_object(builder, "estadisticas_boton");
	g_signal_connect(estadisticas_boton, "activate", G_CALLBACK(mostrar_estadisticas), NULL);


    salir_boton = gtk_builder_get_object(builder, "salir_boton");
	g_signal_connect(salir_boton, "clicked", G_CALLBACK (on_button_clicked_close), window);

	salir_menu = gtk_builder_get_object(builder, "salir_menu");
	g_signal_connect(salir_menu, "activate", G_CALLBACK (on_button_clicked_close), window);




	GtkWidget *btnIniciarJuego = GTK_WIDGET(gtk_builder_get_object(builder, "iniciar_boton"));
	if (btnIniciarJuego) {
	    g_signal_connect(btnIniciarJuego, "clicked", G_CALLBACK(mostrarVentanaConfiguracion), NULL);
	}


	GtkWidget *btnAceptarConfig = GTK_WIDGET(gtk_builder_get_object(builder, "boton_aceptar"));
	if (btnAceptarConfig) {
	    g_signal_connect(btnAceptarConfig, "clicked", G_CALLBACK(aceptarConfiguracion), NULL);
	}




	gtk_widget_set_sensitive(modo_jvc_boton, FALSE);
	gtk_widget_set_sensitive(modo_cvc_boton, FALSE);

	gtk_widget_set_sensitive(modo_jvj_boton, TRUE);

	// etiqueta del info bar
	idEtiquetaInfoBar = gtk_builder_get_object(builder, "etiqueta_info_bar");


	GtkWidget *btnEstadisticas = GTK_WIDGET(gtk_builder_get_object(builder, "btn_estadisticas"));
	if (btnEstadisticas) {
	    g_signal_connect(btnEstadisticas, "clicked", G_CALLBACK(mostrarEstadisticas), NULL);
	} else {
	    g_critical("No se encontró el botón de estadísticas en el archivo Glade.");
	}
	GtkWidget *btnReiniciar = GTK_WIDGET(gtk_builder_get_object(builder, "btn_reiniciar"));
	if (btnReiniciar) {
	    g_signal_connect(btnReiniciar, "clicked", G_CALLBACK(reiniciarJuego), NULL);
	} else {
	    g_critical("No se encontró el botón de reinicio en el archivo Glade.");
	}

	/* Fin de la construcción de la interfaz a partir del archivo generado por el GLADE */

	iniciarJuego(builder);	// inicializamos el juego

	gtk_widget_show_all((GtkWidget *) window);// mostramos la ventana principal

	gtk_main();

	return 0;
}


