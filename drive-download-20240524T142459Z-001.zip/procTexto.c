/*
 ============================================================================
 Name        : tarea.c
 Author      : uu
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void format_text(FILE *input, FILE *output, int max_width) {
    char buffer[1024];
    char word[100];
    int line_length = 0;

    while (fscanf(input, "%s", word) != EOF) {
        int word_length = strlen(word);

        if (line_length + word_length + 1 > max_width) {
            // Si agregar la palabra excede el ancho máximo, empieza una nueva línea
            fprintf(output, "\n");
            line_length = 0;
        }

        if (line_length > 0) {
            // Si no es la primera palabra de la línea, añade un espacio
            fprintf(output, " ");
            line_length++;
        }

        fprintf(output, "%s", word);
        line_length += word_length;
    }

    // Asegura que el último carácter del archivo de salida sea una nueva línea
    fprintf(output, "\n");
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <input file> <output file> <max width>\n", argv[0]);
        return 1;
    }

    const char *input_filename = argv[1];
    const char *output_filename = argv[2];
    int max_width = atoi(argv[3]);

    if (max_width <= 0) {
        fprintf(stderr, "Invalid max width: %s\n", argv[3]);
        return 1;
    }

    FILE *input = fopen(input_filename, "r");
    if (!input) {
        perror("Error opening input file");
        return 1;
    }

    FILE *output = fopen(output_filename, "w");
    if (!output) {
        perror("Error opening output file");
        fclose(input);
        return 1;
    }

    format_text(input, output, max_width);

    fclose(input);
    fclose(output);

    return 0;
}

