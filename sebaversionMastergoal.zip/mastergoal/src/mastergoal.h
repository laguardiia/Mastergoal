/*
 * mastergoal.h
 *
 *  Created on: 7 nov. 2024
 *      Author: lp1
 */

#ifndef MASTERGOAL_H_
#define MASTERGOAL_H_

#define tamX 11
#define tamY 15

/*
 * Estructura para cada jugador con un identificatorio, y su fila y columna
 */
typedef struct {

	int id;
	int pos_x;
	int pos_y;

} jugador;

/*
 * Estructura que representa la pocision de la pelota dentro de la matriz
 */
typedef struct {
    int pos_x;
    int pos_y;
} pelota;

typedef struct {
    char nombre[50];    // Nombre del jugador
    int partidosGanados;
    int partidosPerdidos;
    int partidosEmpatados;
} EstadisticaJugador;

void imprimirCancha(char cancha[tamY][tamX], pelota *p);
int pedirMovimiento(char cancha[tamY][tamX], jugador team[], int tamaño_equipo, int turno);
void pedirMovimientoPelota(char cancha[tamY][tamX], pelota *p, int turno);
int pase (char cancha[tamY][tamX], pelota *p, int nueva_x, int nueva_y, int turno);
int moverJugador(char cancha[tamY][tamX], jugador *j, int nueva_x, int nueva_y);
int moverPelota(char cancha[tamY][tamX], pelota *p, int nueva_x, int nueva_y, int turno);
int verificarPosesion(char cancha[tamY][tamX], pelota *p, int turno);
void inicializarTablero(char cancha[tamY][tamX], jugador team_rojo[], jugador team_blanco[], int tamaño_equipo, pelota *p);
void moverComp(char cancha[tamY][tamX], jugador team[], int tamaño_equipo, pelota *p);
int moverPelotaComp(char cancha[tamY][tamX], pelota *p, int turno);
int verificarGol(pelota *p);
void limpiarBuffer();
int elegirModoDeJuego();
//int elegirColor();
//int elegirEquipoInicial();

#endif /* MASTERGOAL_H_ */
